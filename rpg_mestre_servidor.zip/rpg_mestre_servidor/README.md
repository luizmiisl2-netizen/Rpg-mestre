# RPG Mestre — servidor para 2 jogadores

Este projeto cria uma mesa web em que dois jogadores enviam ações separadamente e o servidor mantém um estado compartilhado da campanha.

## Importante
A parte de IA usa a API da OpenAI. O servidor não transforma esta conversa do ChatGPT em um bot automaticamente; ele faz chamadas à API. Isso exige uma chave de API e pode gerar cobrança conforme o modelo/uso.

## Rodar
1. Instale Python 3.11+.
2. No terminal, entre nesta pasta.
3. `python -m venv .venv`
4. Ative o ambiente virtual.
5. `pip install -r requirements.txt`
6. Copie `.env.example` para `.env` e preencha `OPENAI_API_KEY`.
7. `uvicorn app.main:app --host 0.0.0.0 --port 8000`
8. Abra `http://localhost:8000`.

Para colocar seu amigo pela internet, o servidor precisa estar hospedado em uma máquina/serviço acessível pelos dois. Esta versão já separa as mensagens por jogador.

## Segurança
Esta é uma versão inicial. Antes de abrir para a internet, adicione autenticação, HTTPS e uma senha/convite para a sala.
