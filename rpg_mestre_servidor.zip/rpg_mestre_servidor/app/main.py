import os
import json
import uuid
from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

app = FastAPI(title="RPG Mestre")
BASE = Path(__file__).resolve().parent
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")

# Demo: uma única sala. Para produção, substitua por banco de dados.
STATE = {
    "room": "mesa1",
    "scene": "A campanha ainda não começou.",
    "public_history": [],
    "private": {"luiz": [], "amigo": []},
    "characters": {},
}

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY")) if os.getenv("OPENAI_API_KEY") else None
MODEL = os.getenv("OPENAI_MODEL", "gpt-6.1-sol")

class Action(BaseModel):
    player: str
    text: str

@app.get("/", response_class=HTMLResponse)
def index():
    return (BASE / "static" / "index.html").read_text(encoding="utf-8")

@app.get("/api/state")
def state():
    return {
        "scene": STATE["scene"],
        "public_history": STATE["public_history"][-30:],
        "characters": STATE["characters"],
    }

def fallback_master(player, action):
    return (
        f"O Mestre recebeu a ação de {player}: “{action}”. "
        "Configure OPENAI_API_KEY para que a IA faça a narração, resolva consequências "
        "e mantenha a campanha de forma dinâmica."
    )

@app.post("/api/action")
def action(req: Action):
    player = req.player.strip().lower()
    if player not in ("luiz", "amigo"):
        raise HTTPException(400, "player deve ser 'luiz' ou 'amigo'")
    text = req.text.strip()
    if not text:
        raise HTTPException(400, "Ação vazia")

    # A ação é guardada em área privada até a resolução do turno.
    STATE["private"][player].append({"id": str(uuid.uuid4()), "text": text})

    # Para uma primeira versão, resolvemos assim que ambos têm uma ação.
    other = "amigo" if player == "luiz" else "luiz"
    if not STATE["private"][other]:
        return {"status": "waiting", "message": "Ação recebida. Aguardando o outro jogador."}

    a = STATE["private"]["luiz"][-1]["text"]
    b = STATE["private"]["amigo"][-1]["text"]

    prompt = f"""
Você é o mestre de uma campanha de RPG para dois jogadores.
Resolva o turno de forma justa e criativa.

Ação privada de Luiz:
{a}

Ação privada do Amigo:
{b}

Cena pública atual:
{STATE["scene"]}

Histórico público recente:
{json.dumps(STATE["public_history"][-10:], ensure_ascii=False)}

Responda em JSON válido com:
scene: nova descrição pública da cena
public: texto que ambos podem ver, sem revelar pensamentos/intenções privadas que não
tenham sido descobertos pelos personagens
luiz_private: informação que SOMENTE Luiz deve receber
amigo_private: informação que SOMENTE o Amigo deve receber

Não invente que um personagem sabe algo que só o outro descobriu.
"""

    if client:
        try:
            response = client.responses.create(model=MODEL, input=prompt)
            raw = response.output_text
            # Tenta extrair JSON mesmo se o modelo adicionar texto.
            start, end = raw.find("{"), raw.rfind("}")
            data = json.loads(raw[start:end+1])
        except Exception as exc:
            raise HTTPException(502, f"Falha ao chamar o Mestre de IA: {exc}")
    else:
        data = {
            "scene": STATE["scene"],
            "public": fallback_master("ambos", "As duas ações foram recebidas."),
            "luiz_private": "",
            "amigo_private": "",
        }

    STATE["scene"] = data["scene"]
    STATE["public_history"].append(data["public"])
    STATE["private"]["luiz"].clear()
    STATE["private"]["amigo"].clear()

    return {
        "status": "resolved",
        "scene": data["scene"],
        "public": data["public"],
        "private": {
            "luiz": data.get("luiz_private", ""),
            "amigo": data.get("amigo_private", ""),
        },
    }
